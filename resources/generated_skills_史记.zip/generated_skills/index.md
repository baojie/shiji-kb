```markdown
# 史记技能集合

本技能集合源自中国史学巨著《史记》，涵盖了中国古代从五帝时期到秦汉之际的政治制度、军事策略、历史事件、文化思想等多个领域的专业知识。通过这些技能，用户可以深入了解中国古代历史的核心内容，学习古代政治智慧与军事谋略，研究古代法律制度与思想文化，以及分析历史人物的决策过程。

## 可用技能

| 技能 | 描述 | 使用场景 |
|------|------|----------|
| [shiji-authorship-identification](shiji-authorship-identification/SKILL.md) | 识别和确认《史记》一书的作者信息 | 询问《史记》作者、确认作者归属、查询书目元数据 |
| [three-chapters-law-implementation](three-chapters-law-implementation/SKILL.md) | 实施约法三章政策，废除苛政、建立简化法律体系 | 新政权征服领土、废除前朝严苛法律、急需稳定治理和获取民众支持 |
| [wujiang-refusal-suicide](wujiang-refusal-suicide/SKILL.md) | 处理败军之将在垓下兵败后逃至乌江时的生死抉择 | 询问项羽在乌江的决策过程、分析历史人物的末路选择、研究悲剧英雄心理 |
| [western-zhou-criminal-trial-system](western-zhou-criminal-trial-system/SKILL.md) | 处理西周时期刑事案件审判与刑罚判决的完整流程 | 西周司法审判、刑事案件分析、古代中国法律制度研究 |
| [qin-emperor-title-system](qin-emperor-title-system/SKILL.md) | 处理秦朝皇帝尊号制度的建立与应用 | 处理秦朝政治制度、皇帝称号相关任务、理解中国帝制基础体系 |
| [shang-succession-turmoil-analysis](shang-succession-turmoil-analysis/SKILL.md) | 分析殷商王朝因王位继承制度变更引发的"九世之乱" | 探讨殷商中期历史、继承法演变、诸侯朝贡关系变化 |
| [xihe-calendar-system](xihe-calendar-system/SKILL.md) | 实施帝尧时期的羲和历法授时体系，通过观测星象确定四时节气 | 研究中国古代天文历法、理解传统农业文明的时间管理、分析《史记·五帝本纪》历法制度 |
| [qin-dynasty-thought-control-policy](qin-dynasty-thought-control-policy/SKILL.md) | 分析和执行秦朝焚书坑儒政策 | 研究中国古代思想控制机制、文化政策或法律制度 |
| [hongmen-banquet-escape-strategy](hongmen-banquet-escape-strategy/SKILL.md) | 基于鸿门宴历史事件的逃生策略 | 在危险的政治或社交场合中安全脱身、察觉生命威胁且无法正面冲突 |
| [knowing-employing-talent](knowing-employing-talent/SKILL.md) | 分析领导成败原因，识别核心人才，建立知人善任的领导原则 | 领导者总结经验教训、构建核心团队、面临人才竞争 |
| [burn-boats-break-pots-tactic](burn-boats-break-pots-tactic/SKILL.md) | 通过切断所有退路和限制生存资源来极大提升军队士气的军事战术 | 处于绝境、需要孤注一掷或必须极大提振士气以取得决定性胜利 |
| [qin-water-virtue-system](qin-water-virtue-system/SKILL.md) | 实施基于五德终始说的水德运数制度与国家标准化体系 | 确立政权合法性（特别是取代火德政权）、推行统一的历法、度量衡、文字及行政规范 |
| [fei-feng-feng-xing-jun-xian-zhi](fei-feng-feng-xing-jun-xian-zhi/SKILL.md) | 废除分封制并建立中央集权的郡县制行政体系 | 建立中央集权、统一地方行政管理、避免地方割据、讨论秦朝政治制度改革 |
| [city-surrender-strategy](city-surrender-strategy/SKILL.md) | 通过谈判和封赏手段促使敌方守军投降的策略 | 急于推进战略目标、后方存在威胁、敌方顽强抵抗但可谈判 |
| [muye-battle-execution](muye-battle-execution/SKILL.md) | 执行牧野之战的完整流程，包括军队集结、战前誓师、战斗过程及战后善后 | 分析周武王伐纣的历史事件、研究以少胜多的军事案例、讲解商朝灭亡与周朝建立 |

## 快速导航

### 政治制度
- **qin-emperor-title-system**: 秦朝皇帝尊号制度的建立与应用
- **qin-water-virtue-system**: 基于五德终始说的水德运数制度与国家标准化体系
- **fei-feng-feng-xing-jun-xian-zhi**: 废除分封制，建立中央集权的郡县制
- **western-zhou-criminal-trial-system**: 西周时期刑事案件审判与刑罚判决流程

### 军事策略
- **three-chapters-law-implementation**: 约法三章政策，稳定新征服地区
- **hongmen-banquet-escape-strategy**: 危险场合中的逃生策略
- **burn-boats-break-pots-tactic**: 破釜沉舟，孤注一掷提升士气
- **city-surrender-strategy**: 通过谈判促使敌方守军投降
- **muye-battle-execution**: 牧野之战的完整执行流程

### 历史人物与事件
- **wujiang-refusal-suicide**: 项羽乌江拒渡的生死抉择
- **shang-succession-turmoil-analysis**: 殷商王朝继承制度变更引发的动乱

### 文化思想
- **qin-dynasty-thought-control-policy**: 秦朝焚书坑儒政策分析
- **xihe-calendar-system**: 帝尧时期羲和历法授时体系

### 领导管理
- **knowing-employing-talent**: 知人善任的领导原则与人才识别

### 书目信息
- **shiji-authorship-identification**: 《史记》作者信息识别

## 如何使用

当您需要处理与《史记》相关的任务时，请根据您的具体需求选择相应的技能：

1. **明确任务类型**：确定您需要的是政治制度分析、军事策略建议、历史事件解读，还是其他类型的帮助
2. **查找对应技能**：在"可用技能"表格或"快速导航"中找到最匹配的技能
3. **触发技能**：直接引用技能名称或描述相关场景，系统将自动调用相应的专业知识

例如：
- "我想了解秦朝是如何建立皇帝制度的" → 触发 `qin-emperor-title-system`
- "分析项羽在乌江为什么不渡江" → 触发 `wujiang-refusal-suicide`
- "如何在绝境中提升军队士气" → 触发 `burn-boats-break-pots-tactic`
```